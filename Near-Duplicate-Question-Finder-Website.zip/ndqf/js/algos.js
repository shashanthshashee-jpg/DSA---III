/* ==========================================================================
   algos.js — hand-built algorithm families from the DSA-3 syllabus
   M2 strings · M3 dynamic programming · M4 network flow · M5 approximation · M6 randomised
   Every search routine reports how many character comparisons it really made.
   ========================================================================== */
(function (root) {
  'use strict';
  const D = root.DSA;

  /* ======================= Module 2 — String algorithms ======================= */

  function naiveSearch(t, p) {
    const res = { matches: [], comparisons: 0 };
    const n = t.length, m = p.length;
    if (!m) return res;
    for (let i = 0; i + m <= n; i++) {
      let j = 0;
      while (j < m) { res.comparisons++; if (t[i + j] !== p[j]) break; j++; }
      if (j === m) res.matches.push(i);
    }
    return res;
  }

  function kmpFailure(p) {
    const f = new Array(p.length).fill(0);
    for (let i = 1, k = 0; i < p.length; i++) {
      while (k > 0 && p[i] !== p[k]) k = f[k - 1];
      if (p[i] === p[k]) k++;
      f[i] = k;
    }
    return f;
  }

  function kmpSearch(t, p) {
    const res = { matches: [], comparisons: 0 };
    const m = p.length;
    if (!m) return res;
    const f = kmpFailure(p);
    for (let i = 0, k = 0; i < t.length; i++) {
      while (k > 0 && t[i] !== p[k]) { res.comparisons++; k = f[k - 1]; }
      res.comparisons++;
      if (t[i] === p[k]) k++;
      if (k === m) { res.matches.push(i - m + 1); k = f[k - 1]; }
    }
    return res;
  }

  function zFunction(s) {
    const n = s.length, z = new Array(n).fill(0);
    let l = 0, r = 0, comparisons = 0;
    for (let i = 1; i < n; i++) {
      if (i < r) z[i] = Math.min(r - i, z[i - l]);
      while (i + z[i] < n) {
        comparisons++;
        if (s[z[i]] === s[i + z[i]]) z[i]++; else break;
      }
      if (i + z[i] > r) { l = i; r = i + z[i]; }
    }
    return { z, comparisons };
  }

  function zSearch(t, p) {
    const res = { matches: [], comparisons: 0 };
    if (!p.length) return res;
    const { z, comparisons } = zFunction(p + '\u0001' + t);
    res.comparisons = comparisons;
    for (let i = p.length + 1; i < z.length; i++) if (z[i] >= p.length) res.matches.push(i - p.length - 1);
    return res;
  }

  /* Rabin–Karp with a double polynomial rolling hash; every hash hit is verified. */
  function rabinKarp(t, p) {
    const res = { matches: [], comparisons: 0, hashChecks: 0, spurious: 0 };
    const n = t.length, m = p.length;
    if (!m || m > n) return res;
    const mods = [1000000007, 998244353], bases = [131, 137];
    const ph = [0, 0], th = [0, 0], pw = [1, 1];
    for (let r = 0; r < 2; r++) {
      for (let i = 0; i < m; i++) {
        ph[r] = (ph[r] * bases[r] + p.charCodeAt(i) + 1) % mods[r];
        th[r] = (th[r] * bases[r] + t.charCodeAt(i) + 1) % mods[r];
        if (i < m - 1) pw[r] = (pw[r] * bases[r]) % mods[r];
      }
    }
    for (let i = 0; i + m <= n; i++) {
      res.hashChecks++;
      if (th[0] === ph[0] && th[1] === ph[1]) {
        let ok = true;
        for (let j = 0; j < m; j++) { res.comparisons++; if (t[i + j] !== p[j]) { ok = false; break; } }
        if (ok) res.matches.push(i); else res.spurious++;
      }
      if (i + m < n) {
        for (let r = 0; r < 2; r++) {
          const out = ((t.charCodeAt(i) + 1) * pw[r]) % mods[r];
          th[r] = (((th[r] - out + mods[r]) % mods[r]) * bases[r] + t.charCodeAt(i + m) + 1) % mods[r];
        }
      }
    }
    return res;
  }

  /* Aho–Corasick: trie + failure links, multi-pattern search in one pass. */
  function ahoCorasick(patterns) {
    const nodes = [{ next: {}, fail: 0, out: [] }];
    patterns.forEach((p) => {
      if (!p) return;
      let u = 0;
      for (let ci = 0; ci < p.length; ci++) {
        const c = p[ci];
        if (nodes[u].next[c] === undefined) { nodes.push({ next: {}, fail: 0, out: [] }); nodes[u].next[c] = nodes.length - 1; }
        u = nodes[u].next[c];
      }
      nodes[u].out.push(p);
    });
    const queue = [];
    Object.keys(nodes[0].next).forEach((c) => queue.push(nodes[0].next[c]));
    while (queue.length) {
      const u = queue.shift();
      Object.keys(nodes[u].next).forEach((c) => {
        const v = nodes[u].next[c];
        let f = nodes[u].fail;
        while (f && nodes[f].next[c] === undefined) f = nodes[f].fail;
        nodes[v].fail = nodes[f].next[c] !== undefined && nodes[f].next[c] !== v ? nodes[f].next[c] : 0;
        nodes[v].out = nodes[v].out.concat(nodes[nodes[v].fail].out);
        queue.push(v);
      });
    }
    return {
      nodeCount: nodes.length,
      search(text) {
        const hits = [];
        let u = 0, steps = 0;
        for (let i = 0; i < text.length; i++) {
          const c = text[i];
          while (u && nodes[u].next[c] === undefined) { u = nodes[u].fail; steps++; }
          if (nodes[u].next[c] !== undefined) u = nodes[u].next[c];
          steps++;
          nodes[u].out.forEach((p) => hits.push({ start: i - p.length + 1, pattern: p }));
        }
        return { hits, steps };
      },
    };
  }

  /* Suffix array (prefix doubling, O(n log^2 n) with merge sort) + Kasai LCP. */
  function suffixArray(s) {
    const n = s.length;
    if (!n) return [];
    let sa = [];
    let rank = new Array(n);
    for (let i = 0; i < n; i++) { sa.push(i); rank[i] = s.charCodeAt(i); }
    let tmp = new Array(n);
    for (let k = 1; ; k <<= 1) {
      const cmp = (a, b) => {
        if (rank[a] !== rank[b]) return rank[a] - rank[b];
        return (a + k < n ? rank[a + k] : -1) - (b + k < n ? rank[b + k] : -1);
      };
      sa = D.mergeSort(sa, cmp);
      tmp[sa[0]] = 0;
      for (let i = 1; i < n; i++) tmp[sa[i]] = tmp[sa[i - 1]] + (cmp(sa[i - 1], sa[i]) < 0 ? 1 : 0);
      rank = tmp.slice();
      if (rank[sa[n - 1]] === n - 1 || k > n) break;
    }
    return sa;
  }

  function kasai(s, sa) {
    const n = s.length, rk = new Array(n), lcp = new Array(n).fill(0);
    for (let i = 0; i < n; i++) rk[sa[i]] = i;
    let h = 0;
    for (let i = 0; i < n; i++) {
      if (rk[i] > 0) {
        const j = sa[rk[i] - 1];
        while (i + h < n && j + h < n && s[i + h] === s[j + h]) h++;
        lcp[rk[i]] = h;
        if (h > 0) h--;
      } else h = 0;
    }
    return lcp;
  }

  function longestCommonSubstring(a, b) {
    const s = a + '\u0001' + b;
    const sa = suffixArray(s), lcp = kasai(s, sa);
    let best = 0, pos = 0;
    for (let i = 1; i < sa.length; i++) {
      const x = sa[i - 1], y = sa[i];
      const xa = x < a.length, ya = y < a.length;
      if (xa !== ya && x !== a.length && y !== a.length && lcp[i] > best) { best = lcp[i]; pos = sa[i]; }
    }
    const preview = [];
    for (let i = 0; i < Math.min(sa.length, 12); i++) {
      preview.push({ rank: i, start: sa[i], lcp: lcp[i], suffix: s.slice(sa[i], sa[i] + 22).replace('\u0001', '|') });
    }
    return { text: s.slice(pos, pos + best), length: best, preview, n: s.length };
  }

  /* ======================= Module 3 — Dynamic programming ======================= */

  /* Wagner–Fischer over any two sequences (strings or token arrays). */
  function editDistance(a, b, opts) {
    const o = Object.assign({ variant: 'levenshtein', ins: 1, del: 1, sub: 1, trans: 1 }, opts || {});
    const n = a.length, m = b.length;
    const dp = [];
    for (let i = 0; i <= n; i++) { dp.push(new Array(m + 1).fill(0)); dp[i][0] = i * o.del; }
    for (let j = 0; j <= m; j++) dp[0][j] = j * o.ins;
    const canSwap = (i, j) => o.variant === 'damerau' && i > 1 && j > 1 && a[i - 1] === b[j - 2] && a[i - 2] === b[j - 1];
    for (let i = 1; i <= n; i++) {
      for (let j = 1; j <= m; j++) {
        const cost = a[i - 1] === b[j - 1] ? 0 : o.sub;
        let best = Math.min(dp[i - 1][j] + o.del, dp[i][j - 1] + o.ins, dp[i - 1][j - 1] + cost);
        if (canSwap(i, j)) best = Math.min(best, dp[i - 2][j - 2] + o.trans);
        dp[i][j] = best;
      }
    }
    let i = n, j = m;
    const ops = [], path = [[n, m]];
    while (i > 0 || j > 0) {
      if (i > 0 && j > 0 && a[i - 1] === b[j - 1] && dp[i][j] === dp[i - 1][j - 1]) { ops.push({ op: 'match', a: a[i - 1], b: b[j - 1] }); i--; j--; }
      else if (canSwap(i, j) && dp[i][j] === dp[i - 2][j - 2] + o.trans) { ops.push({ op: 'swap', a: a[i - 2] + a[i - 1], b: b[j - 2] + b[j - 1] }); i -= 2; j -= 2; }
      else if (i > 0 && j > 0 && dp[i][j] === dp[i - 1][j - 1] + o.sub) { ops.push({ op: 'sub', a: a[i - 1], b: b[j - 1] }); i--; j--; }
      else if (i > 0 && dp[i][j] === dp[i - 1][j] + o.del) { ops.push({ op: 'del', a: a[i - 1] }); i--; }
      else { ops.push({ op: 'ins', b: b[j - 1] }); j--; }
      path.push([i, j]);
    }
    ops.reverse();
    return { distance: dp[n][m], matrix: dp, ops, path };
  }

  /* distance only, O(min(n,m)) extra space */
  function levenshtein(a, b) {
    if (a.length < b.length) { const t = a; a = b; b = t; }
    let prev = new Array(b.length + 1), cur = new Array(b.length + 1);
    for (let j = 0; j <= b.length; j++) prev[j] = j;
    for (let i = 1; i <= a.length; i++) {
      cur[0] = i;
      for (let j = 1; j <= b.length; j++) {
        cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      }
      const t = prev; prev = cur; cur = t;
    }
    return prev[b.length];
  }

  /* ======================= Module 4 — Network flow ======================= */

  /* Edmonds–Karp (Ford–Fulkerson with BFS augmenting paths): O(V E^2). */
  function edmondsKarp(n, edgeList, s, t) {
    const to = [], cap = [], adj = [];
    for (let i = 0; i < n; i++) adj.push([]);
    edgeList.forEach(([u, v, c]) => {
      adj[u].push(to.length); to.push(v); cap.push(c);
      adj[v].push(to.length); to.push(u); cap.push(0);
    });
    let flow = 0, augmentations = 0;
    for (;;) {
      const prev = new Array(n).fill(-1);
      const seen = new Array(n).fill(false);
      seen[s] = true;
      const q = [s];
      while (q.length && !seen[t]) {
        const u = q.shift();
        for (const e of adj[u]) if (!seen[to[e]] && cap[e] > 0) { seen[to[e]] = true; prev[to[e]] = e; q.push(to[e]); }
      }
      if (!seen[t]) break;
      let b = Infinity;
      for (let v = t; v !== s; v = to[prev[v] ^ 1]) b = Math.min(b, cap[prev[v]]);
      for (let v = t; v !== s; v = to[prev[v] ^ 1]) { cap[prev[v]] -= b; cap[prev[v] ^ 1] += b; }
      flow += b; augmentations++;
    }
    const used = edgeList.map(([u, v, c], i) => ({ u, v, flow: c - cap[2 * i] }));
    return { flow, augmentations, used };
  }

  /* Capacitated assignment: left node i (cap 1) -> right node j (cap `rightCap`). */
  function assignmentByFlow(L, R, pairs, rightCap) {
    const S = 0, T = L + R + 1, n = L + R + 2;
    const edges = [];
    for (let i = 0; i < L; i++) edges.push([S, 1 + i, 1]);
    for (let j = 0; j < R; j++) edges.push([1 + L + j, T, rightCap]);
    pairs.forEach(([i, j]) => edges.push([1 + i, 1 + L + j, 1]));
    const r = edmondsKarp(n, edges, S, T);
    const matches = [];
    r.used.forEach((e) => { if (e.flow > 0 && e.u >= 1 && e.u <= L && e.v > L && e.v < T) matches.push([e.u - 1, e.v - 1 - L]); });
    return { size: r.flow, matches, augmentations: r.augmentations, V: n, E: edges.length };
  }

  /* ======================= Module 5 — Approximation ======================= */

  /* 2-approximation: take both endpoints of a greedily built maximal matching. */
  function vertexCover2Approx(edges) {
    const covered = {};
    const matching = [];
    edges.forEach(([u, v]) => {
      if (!covered[u] && !covered[v]) { covered[u] = covered[v] = true; matching.push([u, v]); }
    });
    return { cover: Object.keys(covered).map(Number), matching };
  }

  /* exact optimum by bitmask search; only for small graphs (<= 20 vertices) */
  function minVertexCoverExact(vertices, edges) {
    const n = vertices.length;
    if (n > 20) return null;
    const idx = {};
    vertices.forEach((v, i) => { idx[v] = i; });
    const em = edges.map(([u, v]) => (1 << idx[u]) | (1 << idx[v]));
    let best = n;
    for (let mask = 0; mask < (1 << n); mask++) {
      let pc = 0;
      for (let x = mask; x; x &= x - 1) pc++;
      if (pc >= best) continue;
      let ok = true;
      for (let e = 0; e < em.length; e++) if (!(em[e] & mask)) { ok = false; break; }
      if (ok) best = pc;
    }
    return best;
  }

  /* ======================= Module 6 — Randomised ======================= */

  /* MinHash from a universal hash family h(x) = (a x + b) mod p, p = 2^31 - 1 (prime). */
  const P31 = 2147483647n;
  function minHashSignature(xs, numHash, seed) {
    const rng = D.mulberry32(seed);
    const sig = new Array(numHash).fill(Infinity);
    for (let i = 0; i < numHash; i++) {
      const a = BigInt(1 + Math.floor(rng() * 2147483646));
      const b = BigInt(Math.floor(rng() * 2147483647));
      for (let t = 0; t < xs.length; t++) {
        const v = Number((a * BigInt(xs[t]) + b) % P31);
        if (v < sig[i]) sig[i] = v;
      }
    }
    return sig;
  }
  function minHashEstimate(a, b) {
    let eq = 0;
    const slots = [];
    for (let i = 0; i < a.length; i++) { const m = a[i] === b[i] && a[i] !== Infinity; if (m) eq++; slots.push(m); }
    return { estimate: a.length ? eq / a.length : 0, slots };
  }

  function reservoirSample(arr, k, rng) {
    const res = [];
    for (let i = 0; i < arr.length; i++) {
      if (i < k) res.push(arr[i]);
      else { const j = Math.floor(rng() * (i + 1)); if (j < k) res[j] = arr[i]; }
    }
    return res;
  }

  /* work/span model for scoring c candidates then reducing to top-k (Brent's bound) */
  function workSpan(c, k) {
    const work = Math.max(1, c) * (1 + Math.ceil(Math.log2(Math.max(2, k))));
    const span = 1 + Math.ceil(Math.log2(Math.max(2, c))) * Math.ceil(Math.log2(Math.max(2, k)) + 1);
    return { work, span, ceiling: work / span, brent: (p) => work / p + span };
  }

  Object.assign(D, {
    naiveSearch, kmpFailure, kmpSearch, zFunction, zSearch, rabinKarp, ahoCorasick,
    suffixArray, kasai, longestCommonSubstring,
    editDistance, levenshtein,
    edmondsKarp, assignmentByFlow,
    vertexCover2Approx, minVertexCoverExact,
    minHashSignature, minHashEstimate, reservoirSample, workSpan,
  });
})(typeof window !== 'undefined' ? window : globalThis);
