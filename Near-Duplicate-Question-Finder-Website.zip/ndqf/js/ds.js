/* ==========================================================================
   ds.js — hand-built data structures (no Map / Set / sort used by the engine)
   HashMap (separate chaining, prime capacity), HashSet, MinHeap, TopK
   Module 6 link: table sizes are primes found with Miller–Rabin.
   ========================================================================== */
(function (root) {
  'use strict';
  const D = (root.DSA = root.DSA || {});

  /* ---------- stable merge sort (replaces Array.prototype.sort) ---------- */
  function mergeSort(arr, cmp) {
    if (arr.length < 2) return arr.slice();
    const mid = arr.length >> 1;
    const a = mergeSort(arr.slice(0, mid), cmp);
    const b = mergeSort(arr.slice(mid), cmp);
    const out = [];
    let i = 0, j = 0;
    while (i < a.length && j < b.length) out.push(cmp(a[i], b[j]) <= 0 ? a[i++] : b[j++]);
    while (i < a.length) out.push(a[i++]);
    while (j < b.length) out.push(b[j++]);
    return out;
  }

  /* ---------- number theory (Module 6: randomised primality) ---------- */
  function modPow(b, e, m) {
    let r = 1n;
    b %= m;
    while (e > 0n) {
      if (e & 1n) r = (r * b) % m;
      b = (b * b) % m;
      e >>= 1n;
    }
    return r;
  }

  const SMALL_PRIMES = [2n, 3n, 5n, 7n, 11n, 13n, 17n, 19n, 23n, 29n, 31n, 37n];

  /* Miller–Rabin. `bases` optional (array of numbers/BigInts). Without bases the first 12 primes
     are used, which is deterministic for every n < 3.3e24. Returns { prime, witness, rounds }. */
  function millerRabin(nIn, bases) {
    const n = BigInt(nIn);
    if (n < 2n) return { prime: false, witness: null, rounds: 0, note: 'n < 2' };
    for (const p of SMALL_PRIMES) {
      if (n === p) return { prime: true, witness: null, rounds: 0, note: 'small prime' };
      if (n % p === 0n) return { prime: false, witness: p.toString(), rounds: 0, note: 'divisible by ' + p };
    }
    let d = n - 1n, s = 0;
    while ((d & 1n) === 0n) { d >>= 1n; s++; }
    const list = bases ? bases.map(BigInt) : SMALL_PRIMES;
    let rounds = 0;
    for (let a of list) {
      a %= n;
      if (a < 2n) continue;
      rounds++;
      let x = modPow(a, d, n);
      if (x === 1n || x === n - 1n) continue;
      let composite = true;
      for (let r = 1; r < s; r++) {
        x = (x * x) % n;
        if (x === n - 1n) { composite = false; break; }
      }
      if (composite) return { prime: false, witness: a.toString(), rounds, note: 'witness found' };
    }
    return { prime: true, witness: null, rounds, note: 'probably prime' };
  }

  function mulberry32(seed) {
    let a = seed | 0;
    return function () {
      a = (a + 0x6d2b79f5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /* Monte-Carlo variant: k random bases. */
  function millerRabinRandom(nIn, rounds, rng) {
    const n = BigInt(nIn);
    if (n < 5n) return millerRabin(n);
    const bases = [];
    for (let i = 0; i < rounds; i++) {
      const r = BigInt(Math.floor(rng() * 2 ** 52));
      bases.push((r % (n - 3n)) + 2n);
    }
    // skip the small-prime shortcut so the random bases are what decides
    let d = n - 1n, s = 0;
    while ((d & 1n) === 0n) { d >>= 1n; s++; }
    for (const a of bases) {
      let x = modPow(a, d, n);
      if (x === 1n || x === n - 1n) continue;
      let composite = true;
      for (let r = 1; r < s; r++) {
        x = (x * x) % n;
        if (x === n - 1n) { composite = false; break; }
      }
      if (composite) return { prime: false, witness: a.toString(), rounds, bases: bases.map(String) };
    }
    return { prime: true, witness: null, rounds, bases: bases.map(String) };
  }

  function nextPrime(n) {
    let c = Math.max(2, Math.floor(n));
    if (c > 2 && c % 2 === 0) c++;
    while (!millerRabin(c).prime) c += c === 2 ? 1 : 2;
    return c;
  }

  /* ---------- HashMap : separate chaining ---------- */
  class HashMap {
    constructor(cap = 11) {
      this.cap = nextPrime(cap);
      this.buckets = new Array(this.cap);
      this.n = 0;
      this.resizes = 0;
      this.collisions = 0;
    }
    static hashStr(s) {
      let h = 5381;
      for (let i = 0; i < s.length; i++) h = (Math.imul(h, 33) + s.charCodeAt(i)) | 0;
      return h >>> 0;
    }
    indexOf(key) { return HashMap.hashStr(String(key)) % this.cap; }
    put(key, val) {
      key = String(key);
      const i = this.indexOf(key);
      let b = this.buckets[i];
      if (!b) b = this.buckets[i] = [];
      for (let t = 0; t < b.length; t++) {
        if (b[t].k === key) { b[t].v = val; return false; }
      }
      if (b.length) this.collisions++;
      b.push({ k: key, v: val });
      this.n++;
      if (this.n / this.cap > 0.75) this._resize();
      return true;
    }
    get(key) {
      key = String(key);
      const b = this.buckets[this.indexOf(key)];
      if (!b) return undefined;
      for (let t = 0; t < b.length; t++) if (b[t].k === key) return b[t].v;
      return undefined;
    }
    has(key) { return this.get(key) !== undefined; }
    remove(key) {
      key = String(key);
      const i = this.indexOf(key);
      const b = this.buckets[i];
      if (!b) return false;
      for (let t = 0; t < b.length; t++) {
        if (b[t].k === key) { b.splice(t, 1); this.n--; return true; }
      }
      return false;
    }
    forEach(fn) {
      for (let i = 0; i < this.cap; i++) {
        const b = this.buckets[i];
        if (b) for (let t = 0; t < b.length; t++) fn(b[t].k, b[t].v);
      }
    }
    keys() { const out = []; this.forEach((k) => out.push(k)); return out; }
    _resize() {
      const old = this.buckets;
      const oldCap = this.cap;
      this.cap = nextPrime(oldCap * 2);
      this.buckets = new Array(this.cap);
      this.collisions = 0;
      this.resizes++;
      for (let i = 0; i < oldCap; i++) {
        const b = old[i];
        if (!b) continue;
        for (let t = 0; t < b.length; t++) {
          const j = this.indexOf(b[t].k);
          if (!this.buckets[j]) this.buckets[j] = [];
          else this.collisions++;
          this.buckets[j].push(b[t]);
        }
      }
    }
    chainLengths() {
      const out = new Array(this.cap);
      for (let i = 0; i < this.cap; i++) out[i] = this.buckets[i] ? this.buckets[i].length : 0;
      return out;
    }
    stats() {
      let maxChain = 0, used = 0;
      for (let i = 0; i < this.cap; i++) {
        const l = this.buckets[i] ? this.buckets[i].length : 0;
        if (l) used++;
        if (l > maxChain) maxChain = l;
      }
      return {
        capacity: this.cap, size: this.n, loadFactor: this.n / this.cap,
        usedBuckets: used, maxChain, collisions: this.collisions, resizes: this.resizes,
      };
    }
  }

  /* ---------- HashSet built on HashMap ---------- */
  class HashSet {
    constructor() { this.m = new HashMap(); }
    add(x) { return this.m.put(x, true); }
    has(x) { return this.m.has(x); }
    remove(x) { return this.m.remove(x); }
    get size() { return this.m.n; }
    toArray() { return this.m.keys(); }
    forEach(fn) { this.m.forEach((k) => fn(k)); }
    static intersectionSize(a, b) {
      const small = a.size <= b.size ? a : b;
      const large = small === a ? b : a;
      let c = 0;
      small.forEach((k) => { if (large.has(k)) c++; });
      return c;
    }
    static jaccard(a, b) {
      const inter = HashSet.intersectionSize(a, b);
      const uni = a.size + b.size - inter;
      return { inter, uni, score: uni ? inter / uni : 0 };
    }
  }

  /* ---------- binary min-heap ---------- */
  class MinHeap {
    constructor(cmp) { this.a = []; this.cmp = cmp; }
    get size() { return this.a.length; }
    peek() { return this.a[0]; }
    push(x) { this.a.push(x); this._up(this.a.length - 1); }
    pop() {
      const a = this.a;
      if (!a.length) return undefined;
      const top = a[0];
      const last = a.pop();
      if (a.length) { a[0] = last; this._down(0); }
      return top;
    }
    replaceRoot(x) { const old = this.a[0]; this.a[0] = x; this._down(0); return old; }
    toArray() { return this.a.slice(); }
    _up(i) {
      const a = this.a;
      while (i > 0) {
        const p = (i - 1) >> 1;
        if (this.cmp(a[i], a[p]) < 0) { const t = a[i]; a[i] = a[p]; a[p] = t; i = p; } else break;
      }
    }
    _down(i) {
      const a = this.a, n = a.length;
      for (;;) {
        const l = 2 * i + 1, r = l + 1;
        let m = i;
        if (l < n && this.cmp(a[l], a[m]) < 0) m = l;
        if (r < n && this.cmp(a[r], a[m]) < 0) m = r;
        if (m === i) break;
        const t = a[i]; a[i] = a[m]; a[m] = t; i = m;
      }
    }
  }

  /* "weaker" = lower score; equal scores -> larger id is weaker (deterministic ties) */
  function weaker(a, b) { return a.score !== b.score ? a.score - b.score : b.id - a.id; }

  /* Bounded priority queue keeping the K best items; O(log K) per accepted offer. */
  class TopK {
    constructor(k) { this.k = Math.max(1, k | 0); this.heap = new MinHeap(weaker); this.log = []; this.offers = 0; this.heapOps = 0; }
    offer(item) {
      this.offers++;
      const h = this.heap;
      if (h.size < this.k) {
        h.push(item); this.heapOps++;
        this.log.push({ type: 'insert', item, heap: h.toArray() });
        return true;
      }
      if (weaker(item, h.peek()) > 0) {
        const out = h.replaceRoot(item); this.heapOps++;
        this.log.push({ type: 'replace', item, evicted: out, heap: h.toArray() });
        return true;
      }
      this.log.push({ type: 'skip', item, root: h.peek() });
      return false;
    }
    result() {
      const c = new MinHeap(weaker);
      c.a = this.heap.toArray();
      const out = [];
      while (c.size) out.push(c.pop());
      return out.reverse();
    }
  }

  Object.assign(D, {
    mergeSort, modPow, millerRabin, millerRabinRandom, nextPrime, mulberry32,
    HashMap, HashSet, MinHeap, TopK, weaker,
  });
})(typeof window !== 'undefined' ? window : globalThis);
