/* ==========================================================================
   text.js — normalisation, tokenisation, stop-word removal, shingling, hashing
   Hashing is a double polynomial (Rabin–Karp style) hash: Module 2 / Module 6.
   ========================================================================== */
(function (root) {
  'use strict';
  const D = root.DSA;

  const STOP_LIST = (
    'a an the is are was were be been being am i me my we our you your it its this that these those ' +
    'do does did doing done have has had can could would should will shall may might must to of in on at by for ' +
    'with about from into as and or but if then than so such what which who whom whose when where why how also just ' +
    'please using way ways best good help there their them they he she his her some any'
  ).split(' ');

  const STOPWORDS = new D.HashSet();
  STOP_LIST.forEach((w) => STOPWORDS.add(w));

  const WORD_CHAR = /[\p{L}\p{N}\p{M}+#]/u;

  function normalize(text) {
    const s = String(text).toLowerCase();
    let out = '';
    for (let i = 0; i < s.length; i++) out += WORD_CHAR.test(s[i]) ? s[i] : ' ';
    return tokenize(out).join(' ');
  }

  function tokenize(s) {
    const out = [];
    let cur = '';
    for (let i = 0; i < s.length; i++) {
      if (s[i] === ' ') { if (cur) { out.push(cur); cur = ''; } } else cur += s[i];
    }
    if (cur) out.push(cur);
    return out;
  }

  function removeStopwords(tokens) {
    const flags = tokens.map((t) => STOPWORDS.has(t));
    let kept = tokens.filter((_, i) => !flags[i]);
    if (!kept.length && tokens.length) { kept = tokens.slice(); return { kept, flags: flags.map(() => false) }; }
    return { kept, flags };
  }

  /* Double polynomial rolling-style hash of a string -> 16 hex chars (two 30-bit residues). */
  const M1 = 1000000007, M2 = 998244353, B1 = 131, B2 = 137;
  function polyHash(s) {
    let h1 = 0, h2 = 0;
    for (let i = 0; i < s.length; i++) {
      const c = s.charCodeAt(i) + 1;
      h1 = (h1 * B1 + c) % M1;
      h2 = (h2 * B2 + c) % M2;
    }
    return { h1, h2, key: h1.toString(16).padStart(8, '0') + h2.toString(16).padStart(8, '0') };
  }

  const MODES = {
    '1+2': { label: 'Words + word pairs', sizes: [1, 2] },
    '2': { label: '2-word shingles', sizes: [2] },
    '3': { label: '3-word shingles', sizes: [3] },
    '1': { label: 'Single words (n = 1)', sizes: [1] },
  };

  function makeShingles(tokens, mode) {
    const sizes = (MODES[mode] || MODES['1+2']).sizes;
    const seen = new D.HashSet();
    const out = [];
    const push = (text, n) => {
      if (seen.has(text)) return;
      seen.add(text);
      out.push({ text, n, hash: polyHash(text).key });
    };
    sizes.forEach((n) => {
      for (let i = 0; i + n <= tokens.length; i++) push(tokens.slice(i, i + n).join(' '), n);
    });
    if (!out.length && tokens.length) push(tokens.join(' '), tokens.length); // short-question fallback
    return out;
  }

  function preprocess(text, mode) {
    const normalized = normalize(text);
    const tokens = tokenize(normalized);
    const { kept, flags } = removeStopwords(tokens);
    const shingles = makeShingles(kept, mode);
    const set = new D.HashSet();
    shingles.forEach((s) => set.add(s.hash));
    return { original: String(text), normalized, tokens, flags, kept, shingles, set };
  }

  Object.assign(D, { STOPWORDS, normalize, tokenize, removeStopwords, polyHash, makeShingles, preprocess, MODES });
})(typeof window !== 'undefined' ? window : globalThis);
