/* ==========================================================================
   engine.js — the duplicate-detection engine
   shingles -> HashMap inverted index -> candidate retrieval -> HashSet Jaccard -> TopK heap
   ========================================================================== */
(function (root) {
  'use strict';
  const D = root.DSA;
  const now = () => (typeof performance !== 'undefined' ? performance.now() : Date.now());

  class QuestionIndex {
    constructor(mode = '1+2') {
      this.mode = mode;
      this.questions = [];
      this.nextId = 1;
      this._rebuild();
    }

    load(list) {
      this.questions = list.map((r) => this._make(r.id, r.text));
      this.nextId = list.reduce((m, r) => Math.max(m, r.id), 0) + 1;
      this._rebuild();
    }

    setMode(mode) {
      this.mode = mode;
      this.questions = this.questions.map((q) => this._make(q.id, q.text));
      this._rebuild();
    }

    _make(id, text) { return { id, text, pre: D.preprocess(text, this.mode) }; }

    _rebuild() {
      this.inverted = new D.HashMap();
      this.vocab = new D.HashMap();
      this.byId = new D.HashMap();
      this.questions.forEach((q) => this._indexOne(q));
    }

    _indexOne(q) {
      this.byId.put(q.id, q);
      q.pre.shingles.forEach((s) => {
        let posting = this.inverted.get(s.hash);
        if (!posting) { posting = []; this.inverted.put(s.hash, posting); }
        posting.push(q.id);
      });
      q.pre.kept.forEach((t) => this.vocab.put(t, (this.vocab.get(t) || 0) + 1));
    }

    add(text) {
      const q = this._make(this.nextId++, text);
      this.questions.push(q);
      this._indexOne(q);
      return q;
    }

    remove(id) {
      this.questions = this.questions.filter((q) => q.id !== id);
      this._rebuild();
    }

    get(id) { return this.byId.get(id); }

    /* Indexed search: only questions sharing >= 1 shingle are ever scored. */
    query(text, { k = 5 } = {}) {
      const t0 = now();
      const pre = D.preprocess(text, this.mode);
      const hits = new D.HashMap();
      const lookups = [];
      let postingsScanned = 0;
      pre.shingles.forEach((s) => {
        const posting = this.inverted.get(s.hash);
        lookups.push({ shingle: s, bucket: this.inverted.indexOf(s.hash), posting: posting ? posting.slice() : [] });
        if (posting) {
          postingsScanned += posting.length;
          posting.forEach((id) => hits.put(id, (hits.get(id) || 0) + 1));
        }
      });

      const cand = [];
      hits.forEach((idStr, sharedHits) => {
        const q = this.byId.get(idStr);
        const j = D.HashSet.jaccard(pre.set, q.pre.set);
        cand.push({ id: q.id, score: j.score, inter: j.inter, uni: j.uni, hits: sharedHits });
      });
      const ordered = D.mergeSort(cand, (a, b) => a.id - b.id);

      const top = new D.TopK(k);
      ordered.forEach((c) => top.offer({ id: c.id, score: c.score }));
      const ranked = top.result().map((r) => {
        const q = this.byId.get(r.id);
        const c = ordered.find((x) => x.id === r.id);
        const shared = pre.shingles.filter((s) => q.pre.set.has(s.hash)).map((s) => s.text);
        return { q, score: r.score, inter: c.inter, uni: c.uni, shared };
      });

      const n = this.questions.length;
      return {
        pre, lookups, candidates: ordered, ranked, log: top.log, heap: top.heap.toArray(), k: top.k,
        stats: {
          total: n, candidates: ordered.length, skipped: n - ordered.length,
          postingsScanned, offers: top.offers, heapOps: top.heapOps, ms: now() - t0,
        },
      };
    }

    /* Exhaustive baseline: score EVERY question (used to verify the indexed result). */
    exhaustive(text, { k = 5 } = {}) {
      const t0 = now();
      const pre = D.preprocess(text, this.mode);
      const top = new D.TopK(k);
      this.questions.forEach((q) => {
        const j = D.HashSet.jaccard(pre.set, q.pre.set);
        if (j.score > 0) top.offer({ id: q.id, score: j.score });
      });
      return { ids: top.result().map((r) => r.id), scores: top.result().map((r) => r.score), comparisons: this.questions.length, ms: now() - t0 };
    }

    /* "Did you mean": unknown tokens matched against the vocabulary with edit distance (Module 3). */
    suggest(pre) {
      const out = [];
      pre.kept.forEach((t) => {
        if (this.vocab.has(t) || t.length < 4 || /^[0-9]+$/.test(t)) return;
        const limit = t.length >= 7 ? 2 : 1;
        let best = null;
        this.vocab.forEach((w, freq) => {
          if (Math.abs(w.length - t.length) > limit) return;
          const d = D.levenshtein(t, w);
          if (d <= limit && (!best || d < best.d || (d === best.d && freq > best.freq))) best = { w, d, freq };
        });
        if (best) out.push({ token: t, suggestion: best.w, distance: best.d });
      });
      return out;
    }

    /* all pairs with score >= threshold, generated through the index (no O(N^2) scan) */
    duplicatePairs(threshold) {
      const pairs = [];
      this.questions.forEach((q) => {
        const hits = new D.HashMap();
        q.pre.shingles.forEach((s) => (this.inverted.get(s.hash) || []).forEach((id) => { if (id > q.id) hits.put(id, true); }));
        hits.forEach((idStr) => {
          const o = this.byId.get(idStr);
          const j = D.HashSet.jaccard(q.pre.set, o.pre.set);
          if (j.score >= threshold) pairs.push({ a: q.id, b: o.id, score: j.score });
        });
      });
      return pairs;
    }
  }

  D.QuestionIndex = QuestionIndex;
})(typeof window !== 'undefined' ? window : globalThis);
