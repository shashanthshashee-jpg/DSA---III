/* ==========================================================================
   ui.js — page behaviour: detector, pipeline, index, ranking, database, reference tables
   ========================================================================== */
(function () {
  'use strict';
  const D = window.DSA;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const pct = (x) => Math.round(x * 100) + '%';
  const BANK_KEY = 'ndqf.bank.v1';

  const APP = (window.APP = {
    idx: new D.QuestionIndex('1+2'),
    settings: { mode: '1+2', k: 5, thr: 0.4 },
    last: null,
    $, $$, esc, pct,
  });

  /* ---------- persistence ---------- */
  function loadBank() {
    try {
      const raw = localStorage.getItem(BANK_KEY);
      if (raw) { const list = JSON.parse(raw); if (Array.isArray(list) && list.length) return list; }
    } catch (e) { /* storage unavailable: fall back to seed */ }
    return D.SEED_BANK;
  }
  function saveBank() {
    try { localStorage.setItem(BANK_KEY, JSON.stringify(APP.idx.questions.map((q) => ({ id: q.id, text: q.text })))); } catch (e) { /* ignore */ }
  }
  APP.idx.load(loadBank());

  /* ---------- controls ---------- */
  const qInput = $('#qInput');
  const SAMPLES = [
    'How can I reverse a Java linked list?',
    'binary seerch implementation in python',
    'What is Jaccard similarity of two sets?',
    'implement a priority queue with a heap',
    'What is the best way to learn guitar?',
  ];
  $('#samples').innerHTML = SAMPLES.map((s) => `<button type="button">${esc(s)}</button>`).join('');
  $('#samples').addEventListener('click', (e) => { if (e.target.tagName === 'BUTTON') { qInput.value = e.target.textContent; run(); } });

  $('#modeSel').innerHTML = Object.keys(D.MODES).map((k) => `<option value="${k}">${esc(D.MODES[k].label)}</option>`).join('');
  $('#modeSel').value = APP.settings.mode;
  $('#modeSel').addEventListener('change', (e) => { APP.settings.mode = e.target.value; APP.idx.setMode(APP.settings.mode); renderBank(); run(); APP.refreshLab && APP.refreshLab(); });
  $('#kSel').addEventListener('change', (e) => { APP.settings.k = +e.target.value; run(); });
  $('#thr').addEventListener('input', (e) => { APP.settings.thr = +e.target.value / 100; $('#thrVal').textContent = e.target.value + '%'; run(); });
  $('#checkBtn').addEventListener('click', run);
  let timer = null;
  qInput.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(run, 180); });
  qInput.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); run(); } });
  $('#postBtn').addEventListener('click', () => {
    const t = qInput.value.trim();
    if (!t) return;
    const q = APP.idx.add(t);
    saveBank();
    qInput.value = '';
    toast(`Posted as Q${q.id}`);
    renderBank(); run(); APP.refreshLab && APP.refreshLab();
  });

  let toastEl;
  function toast(msg) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.style.cssText = 'position:fixed;left:50%;bottom:28px;transform:translateX(-50%);background:#0e1a35;color:#fff;padding:10px 18px;border-radius:10px;font:600 14px system-ui;z-index:99;box-shadow:0 8px 24px rgba(0,0,0,.25);transition:opacity .25s';
      document.body.appendChild(toastEl);
    }
    toastEl.textContent = msg; toastEl.style.opacity = 1;
    clearTimeout(toastEl._t); toastEl._t = setTimeout(() => { toastEl.style.opacity = 0; }, 1800);
  }
  APP.toast = toast;

  /* ---------- main run ---------- */
  function run() {
    const text = qInput.value.trim();
    const { k, thr } = APP.settings;
    APP.last = text ? APP.idx.query(text, { k }) : null;
    renderDetector(text, thr);
    renderPipeline(text);
    renderIndex();
    renderRanking();
    renderHero();
    $('#postBtn').disabled = !text;
  }
  APP.run = run;

  function renderDetector(text, thr) {
    const res = APP.last, verdict = $('#verdict');
    if (!res) {
      verdict.className = 'verdict idle';
      verdict.innerHTML = '<span class="ico">?</span><div>Type a question to check it against the database.<small>Results update as you type.</small></div>';
      $('#results').innerHTML = ''; $('#detStats').innerHTML = ''; $('#suggestions').innerHTML = '';
      return;
    }
    const top = res.ranked[0];
    if (top && top.score >= thr) {
      verdict.className = 'verdict dup';
      verdict.innerHTML = `<span class="ico">!</span><div>Possible duplicate detected<small>Closest match: Q${top.q.id} at ${pct(top.score)} similarity — consider using the existing thread.</small></div>`;
    } else {
      verdict.className = 'verdict new';
      const why = top ? `Closest candidate is only ${pct(top.score)} similar (threshold ${pct(thr)}).` : 'No existing question shares a single shingle with this one.';
      verdict.innerHTML = `<span class="ico">✓</span><div>No close match — this looks like a new question<small>${esc(why)}</small></div>`;
    }
    $('#results').innerHTML = res.ranked.length ? res.ranked.map((r, i) => {
      const hit = r.score >= thr;
      const shown = r.shared.slice(0, 8).map((s) => `<span class="chip ${s.indexOf(' ') > -1 ? 'n2' : ''}">${esc(s)}</span>`).join('');
      const more = r.shared.length > 8 ? `<span class="chip">+${r.shared.length - 8}</span>` : '';
      return `<div class="res ${hit ? 'hit' : ''}">
        <div class="res-top"><span class="rank">${i + 1}</span><div class="res-q"><small>Q${r.q.id}</small>${esc(r.q.text)}</div><span class="pct">${pct(r.score)}</span></div>
        <div class="bar"><i style="width:${Math.max(2, r.score * 100)}%"></i></div>
        <div class="chips">${shown}${more}</div>
        <div class="res-meta">shared shingles ${r.inter} ÷ union ${r.uni} = ${r.score.toFixed(3)}</div></div>`;
    }).join('') : '<div class="empty">No candidates — nothing in the database overlaps with this question.</div>';

    const s = res.stats;
    const ex = APP.idx.exhaustive(text, { k: res.k });
    const same = JSON.stringify(ex.ids) === JSON.stringify(res.ranked.map((r) => r.q.id));
    $('#detStats').innerHTML = `
      <div class="stat"><b>${s.candidates}</b><span>candidates scored</span></div>
      <div class="stat"><b>${s.skipped}</b><span>skipped by index</span></div>
      <div class="stat"><b>${s.postingsScanned}</b><span>postings read</span></div>
      <div class="stat"><b>${s.ms < 0.01 ? '<0.01' : s.ms.toFixed(2)} ms</b><span>query time</span></div>
      <div class="verify" style="grid-column:1/-1">${same ? '✓' : '⚠'} <b>${same ? 'Verified:' : 'Mismatch:'}</b> the indexed top-${res.k} ${same ? 'is identical to' : 'differs from'} an exhaustive scan of all ${s.total} questions (${s.candidates} vs ${ex.comparisons} similarity computations).</div>`;

    const sug = APP.idx.suggest(res.pre);
    $('#suggestions').innerHTML = sug.length
      ? 'Did you mean ' + sug.map((x) => `<button type="button" data-from="${esc(x.token)}" data-to="${esc(x.suggestion)}">${esc(x.suggestion)}</button> <span class="muted">(for “${esc(x.token)}”, edit distance ${x.distance})</span>`).join(', ') + '?'
      : '';
  }
  $('#suggestions').addEventListener('click', (e) => {
    const b = e.target.closest('button'); if (!b) return;
    const re = new RegExp('\\b' + b.dataset.from.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'gi');
    qInput.value = qInput.value.replace(re, b.dataset.to);
    run();
  });

  /* ---------- pipeline ---------- */
  function renderPipeline(text) {
    const box = $('#pipeSteps');
    if (!APP.last) { box.innerHTML = '<div class="empty">Enter a question above to see every stage of the pipeline.</div>'; return; }
    const p = APP.last.pre;
    const kept = p.flags.filter((f) => !f).length;
    const tokChips = p.tokens.map((t, i) => `<span class="chip ${p.flags[i] ? 'stop' : 'kept'}">${esc(t)}</span>`).join('') || '<span class="muted">—</span>';
    const shChips = p.shingles.map((s) => `<span class="chip ${s.n > 1 ? 'n2' : ''}">${esc(s.text)}</span>`).join('') || '<span class="muted">—</span>';
    const rows = p.shingles.slice(0, 12).map((s) => `<tr><td>${esc(s.text)}</td><td class="mono">${s.hash.slice(0, 8)}…</td><td class="mono">${APP.idx.inverted.indexOf(s.hash)}</td></tr>`).join('');
    box.innerHTML = `
      <div class="step"><div><h4><span>1</span>Original</h4><p>Raw text as typed.</p></div><div class="body"><div class="mono-box">${esc(p.original)}</div></div></div>
      <div class="step"><div><h4><span>2</span>Normalisation</h4><p>Lower-case; punctuation becomes a space.</p></div><div class="body"><div class="mono-box">${esc(p.normalized) || '—'}</div></div></div>
      <div class="step"><div><h4><span>3</span>Tokens &amp; stop-words</h4><p>${kept} of ${p.tokens.length} tokens kept. Each token is looked up in a HashSet of stop-words: O(1).</p></div><div class="body"><div class="chips">${tokChips}</div></div></div>
      <div class="step"><div><h4><span>4</span>Shingles</h4><p>${p.shingles.length} unique shingles (${esc(D.MODES[APP.settings.mode].label)}). Stored in a HashSet so duplicates collapse.</p></div><div class="body"><div class="chips">${shChips}</div></div></div>
      <div class="step"><div><h4><span>5</span>Hash values</h4><p>Double polynomial hash (two moduli, 16 hex digits) → bucket in the index table.</p></div><div class="body"><table class="hash-tbl"><tr><th>Shingle</th><th>Hash</th><th>Bucket</th></tr>${rows}</table>${p.shingles.length > 12 ? `<p class="muted">… and ${p.shingles.length - 12} more</p>` : ''}</div></div>`;
  }

  /* ---------- index ---------- */
  function renderIndex() {
    const st = APP.idx.inverted.stats();
    $('#idxStats').innerHTML = `
      <div class="kpi"><span>Distinct shingles</span><b>${st.size}</b><small>keys in the inverted index</small></div>
      <div class="kpi"><span>Buckets</span><b>${st.capacity}</b><small>prime size · ${st.resizes} resizes</small></div>
      <div class="kpi"><span>Load factor</span><b>${st.loadFactor.toFixed(2)}</b><small>resize above 0.75</small></div>
      <div class="kpi"><span>Longest chain</span><b>${st.maxChain}</b><small>${st.collisions} collisions handled by chaining</small></div>`;

    const res = APP.last, hitBuckets = {};
    if (!res) {
      $('#lookupTbl').innerHTML = '<tr><td class="muted">Enter a question to see its index lookups.</td></tr>';
      $('#cmpBars').innerHTML = '<div class="empty">Waiting for a question…</div>';
    } else {
      res.lookups.forEach((l) => { hitBuckets[l.bucket] = true; });
      const rows = res.lookups.map((l) => {
        const ids = l.posting.slice(0, 8).map((i) => 'Q' + i).join(', ') + (l.posting.length > 8 ? ` +${l.posting.length - 8}` : '');
        return `<tr><td>${esc(l.shingle.text)}</td><td class="num">${l.bucket}</td><td>${l.posting.length ? esc(ids) : '<span class="muted">no match</span>'}</td></tr>`;
      }).join('');
      $('#lookupTbl').innerHTML = `<tr><th>Shingle</th><th>Bucket</th><th>Questions containing it</th></tr>${rows}`;
      const s = res.stats, saved = s.total ? Math.round(((s.total - s.candidates) / s.total) * 100) : 0;
      $('#cmpBars').innerHTML = `
        <div class="cbar"><div class="cbar-top"><span>Exhaustive: score every question</span><b>${s.total}</b></div><div class="cbar-track"><i style="width:100%"></i></div></div>
        <div class="cbar good"><div class="cbar-top"><span>Indexed: score candidates only</span><b>${s.candidates}</b></div><div class="cbar-track"><i style="width:${s.total ? Math.max(1, (s.candidates / s.total) * 100) : 0}%"></i></div></div>
        <p class="muted sm-t">${saved}% fewer similarity computations for this query on a ${s.total}-question database. A question typically shares shingles with only a small slice of the database, so this saving tends to grow as the database grows.</p>`;
    }
    const lens = APP.idx.inverted.chainLengths();
    $('#heat').innerHTML = lens.map((l, i) => `<i class="${l >= 3 ? 'l3' : l === 2 ? 'l2' : l === 1 ? 'l1' : ''} ${hitBuckets[i] ? 'hit' : ''}" title="bucket ${i}: ${l} key${l === 1 ? '' : 's'}"></i>`).join('');
  }

  /* ---------- ranking ---------- */
  function renderRanking() {
    const res = APP.last;
    if (!res) { $('#heapSvg').innerHTML = '<div class="empty">Enter a question to watch the heap fill up.</div>'; $('#heapLog').innerHTML = ''; return; }
    const h = res.heap, W = 560, levels = h.length ? Math.floor(Math.log2(h.length)) + 1 : 1, H = levels * 86 + 24;
    const pos = (i) => { const lv = Math.floor(Math.log2(i + 1)), idx = i + 1 - (1 << lv); return { x: ((idx + 0.5) / (1 << lv)) * W, y: 42 + lv * 86 }; };
    let svg = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Binary min-heap of the current top-K">`;
    h.forEach((_, i) => { if (i > 0) { const a = pos((i - 1) >> 1), b = pos(i); svg += `<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="#c9d4e8" stroke-width="2"/>`; } });
    h.forEach((n, i) => {
      const p = pos(i), root = i === 0;
      svg += `<g><circle cx="${p.x}" cy="${p.y}" r="30" fill="${root ? '#d98e04' : '#16254a'}"/><text x="${p.x}" y="${p.y - 3}" text-anchor="middle" fill="${root ? '#0a1226' : '#fff'}" font-size="13" font-weight="700">Q${n.id}</text><text x="${p.x}" y="${p.y + 13}" text-anchor="middle" fill="${root ? '#0a1226' : '#c7d3ea'}" font-size="12">${pct(n.score)}</text></g>`;
    });
    svg += '</svg>';
    const order = res.ranked.map((r) => `Q${r.q.id} (${pct(r.score)})`).join(' › ');
    $('#heapSvg').innerHTML = (h.length ? svg : '<div class="empty">No candidates were offered to the heap.</div>') +
      `<p class="muted sm-t"><span class="pill acc">root</span> = weakest of the K kept. Polling K times and reversing gives the final order: <b>${esc(order) || '—'}</b></p>`;
    $('#heapLog').innerHTML = res.log.slice(0, 60).map((l) => {
      const it = `Q${l.item.id} (${pct(l.item.score)})`;
      if (l.type === 'insert') return `<li class="ins"><span class="t">insert</span> ${it} — heap not full yet, push + sift up</li>`;
      if (l.type === 'replace') return `<li class="rep"><span class="t">replace</span> ${it} beats root Q${l.evicted.id} (${pct(l.evicted.score)}) — swap root, sift down</li>`;
      return `<li class="skp"><span class="t">skip</span> ${it} does not beat root Q${l.root.id} (${pct(l.root.score)}) — O(1)</li>`;
    }).join('') + (res.log.length > 60 ? `<li class="muted">… ${res.log.length - 60} more</li>` : '');
  }

  function renderHero() {
    const st = APP.idx.inverted.stats();
    $('#heroStats').innerHTML = `<div><b>${APP.idx.questions.length}</b><span>questions</span></div><div><b>${st.size}</b><span>indexed shingles</span></div><div><b>${st.capacity}</b><span>hash buckets</span></div>`;
  }

  /* ---------- database ---------- */
  function renderBank() {
    const f = $('#bankFilter').value.trim().toLowerCase();
    const rows = [];
    APP.idx.questions.forEach((q) => {
      const low = q.text.toLowerCase();
      let html = esc(q.text);
      if (f) {
        const m = D.kmpSearch(low, f).matches;
        if (!m.length) return;
        const s = m[0];
        html = esc(q.text.slice(0, s)) + '<mark>' + esc(q.text.slice(s, s + f.length)) + '</mark>' + esc(q.text.slice(s + f.length));
      }
      rows.push(`<tr><td class="num">Q${q.id}</td><td>${html}</td><td class="num">${q.pre.shingles.length}</td><td><button class="x" data-del="${q.id}" title="Delete" aria-label="Delete Q${q.id}">✕</button></td></tr>`);
    });
    $('#bankTbl').innerHTML = `<tr><th style="width:70px">ID</th><th>Question</th><th style="width:90px">Shingles</th><th style="width:50px"></th></tr>${rows.join('')}`;
    $('#bankCount').textContent = `${rows.length} of ${APP.idx.questions.length} questions shown${f ? ' (KMP substring match)' : ''}. Changes are stored in this browser only.`;
  }
  APP.renderBank = renderBank;
  $('#bankFilter').addEventListener('input', renderBank);
  $('#bankTbl').addEventListener('click', (e) => {
    const b = e.target.closest('[data-del]'); if (!b) return;
    APP.idx.remove(+b.dataset.del); saveBank(); renderBank(); run(); APP.refreshLab && APP.refreshLab();
  });
  function addFromBank() {
    const t = $('#bankAdd').value.trim(); if (!t) return;
    const q = APP.idx.add(t); saveBank(); $('#bankAdd').value = ''; toast(`Added as Q${q.id}`); renderBank(); run(); APP.refreshLab && APP.refreshLab();
  }
  $('#bankAddBtn').addEventListener('click', addFromBank);
  $('#bankAdd').addEventListener('keydown', (e) => { if (e.key === 'Enter') addFromBank(); });
  $('#bankReset').addEventListener('click', () => {
    APP.idx.load(D.SEED_BANK); saveBank(); renderBank(); run(); APP.refreshLab && APP.refreshLab(); toast('Sample data restored');
  });

  /* ---------- static reference tables ---------- */
  const COMPLEXITY = [
    ['HashMap put / get / remove', 'avg O(1) · worst O(n)', 'O(n)', 'Inverted index, vocabulary'],
    ['HashSet add / contains', 'avg O(1)', 'O(n)', 'Stop-words, shingle sets'],
    ['Normalise + tokenise a question', 'O(L)', 'O(L)', 'Preprocessing, L = characters'],
    ['Shingle hashing (polynomial)', 'O(L · n)', 'O(s)', 'n = shingle size, s = shingles'],
    ['Build inverted index', 'O(N · s) expected', 'O(N · s)', 'One posting per (shingle, question)'],
    ['Candidate retrieval', 'O(s + Σ postings)', 'O(c)', 'Only questions sharing a shingle'],
    ['Jaccard for one candidate', 'O(min(|A|,|B|)) expected', 'O(1)', 'HashSet intersection'],
    ['Top-K with bounded min-heap', 'O(c log K)', 'O(K)', 'Priority Queue'],
    ['Exhaustive baseline', 'O(N · min(|A|,|B|))', 'O(K)', 'Shown for comparison'],
    ['KMP / Z-function', 'O(n + m)', 'O(m)', 'M2 · pattern search'],
    ['Rabin–Karp (double hash)', 'avg O(n + m) · worst O(nm)', 'O(1)', 'M2 · rolling hash'],
    ['Aho–Corasick', 'O(n + m + z)', 'O(m·σ)', 'M2 · multi-pattern'],
    ['Suffix array + Kasai LCP', 'O(n log² n) + O(n)', 'O(n)', 'M2 · longest common substring'],
    ['Edit distance (Wagner–Fischer)', 'O(nm)', 'O(nm) · O(min) distance only', 'M3 · fuzzy matching'],
    ['Edmonds–Karp max-flow', 'O(V E²)', 'O(V + E)', 'M4 · capacitated assignment'],
    ['Vertex cover 2-approximation', 'O(E)', 'O(V)', 'M5 · ratio ≤ 2'],
    ['MinHash signature', 'O(k · |A|)', 'O(k)', 'M6 · k hash functions'],
    ['Miller–Rabin', 'O(r log³ n)', 'O(1)', 'M6 · sizing hash tables'],
    ['Reservoir sampling', 'O(N)', 'O(k)', 'M6 · streaming sample'],
  ];
  $('#complexityTbl').innerHTML = '<tr><th>Operation</th><th>Time</th><th>Space</th><th>Used for</th></tr>' +
    COMPLEXITY.map((r) => `<tr><td>${r[0]}</td><td class="num">${r[1]}</td><td class="num">${r[2]}</td><td>${r[3]}</td></tr>`).join('');

  const COVER = [
    ['M1', 'TextHack as a system', 'Several query classes behind one engine.', ['Document similarity → Detector', 'Pattern search → Database filter', 'Fuzzy matching → “Did you mean”', 'Per-operation cost → Complexity table'], 'detector'],
    ['M2', 'String algorithms', 'Search, hashing and suffix structures.', ['KMP, Z-function, Rabin–Karp, Aho–Corasick', 'Shingle hashing uses a polynomial hash', 'Suffix array + LCP: longest common substring'], 'strings'],
    ['M3', 'Advanced dynamic programming', 'Alignment-style DP on questions.', ['Levenshtein, Damerau, weighted edit distance', 'Full DP table and backtraced alignment', 'Character-level or word-level'], 'dp'],
    ['M4', 'Network flow', 'Assignment as a max-flow problem.', ['Edmonds–Karp augmenting paths', 'Incoming questions → existing threads', 'Capacity per thread, bipartite matching'], 'flow'],
    ['M5', 'NP-completeness & approximation', 'Hard selection, practical answer.', ['Duplicate graph over the whole database', 'Vertex-cover 2-approximation', 'Exact optimum for small graphs'], 'approx'],
    ['M6', 'Randomised & parallel', 'Probabilistic tools and cost models.', ['MinHash with a universal hash family', 'Miller–Rabin sizes the hash tables', 'Reservoir sampling · work/span estimate'], 'random'],
  ];
  $('#coverageGrid').innerHTML = COVER.map((c) => `<button class="cov" type="button" data-go="${c[4]}"><span class="mod">${c[0]}</span><h4>${c[1]}</h4><p>${c[2]}</p><ul>${c[3].map((x) => `<li>${x}</li>`).join('')}</ul></button>`).join('');
  $('#coverageGrid').addEventListener('click', (e) => {
    const b = e.target.closest('[data-go]'); if (!b) return;
    const t = b.dataset.go;
    if (t === 'detector') { document.getElementById('detector').scrollIntoView(); return; }
    APP.openTab(t); document.getElementById('lab').scrollIntoView();
  });
  $('#m1Tbl').innerHTML = '<tr><th>Query class</th><th>Algorithm family</th><th>Where it appears here</th></tr>' + [
    ['Document similarity', 'Hashing + set overlap (shingles, Jaccard); suffix structures', 'Detector · Lab → String algorithms'],
    ['Pattern search', 'String algorithms (KMP, Z, Rabin–Karp, Aho–Corasick)', 'Database filter · Lab → String algorithms'],
    ['Fuzzy matching', 'Dynamic programming (edit distance)', '“Did you mean” · Lab → Edit distance'],
    ['Capacity-constrained assignment', 'Max-flow', 'Lab → Network flow'],
    ['Hard selection problems', 'NP-hard problems with approximation', 'Lab → Approximation'],
    ['Hashing & primality', 'Randomised algorithms', 'Lab → Randomised'],
  ].map((r) => `<tr><td><b>${r[0]}</b></td><td>${r[1]}</td><td>${r[2]}</td></tr>`).join('');

  /* ---------- nav highlight ---------- */
  if ('IntersectionObserver' in window) {
    const links = $$('.links a');
    const io = new IntersectionObserver((entries) => {
      entries.forEach((en) => { if (en.isIntersecting) links.forEach((a) => a.classList.toggle('active', a.getAttribute('href') === '#' + en.target.id)); });
    }, { rootMargin: '-45% 0px -50% 0px' });
    $$('main section[id]').forEach((s) => io.observe(s));
  }

  /* ---------- init ---------- */
  if (window.LAB_INIT) window.LAB_INIT(APP);
  qInput.value = 'How can I reverse a Java linked list?';
  renderBank();
  run();
})();
