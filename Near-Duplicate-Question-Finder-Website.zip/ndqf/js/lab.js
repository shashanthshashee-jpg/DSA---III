/* ==========================================================================
   lab.js — the Algorithm Lab (syllabus modules 2–6 applied to the question database)
   ========================================================================== */
window.LAB_INIT = function (APP) {
  'use strict';
  const D = window.DSA;
  const { $, $$, esc, pct } = APP;
  const idx = () => APP.idx;

  const qOpts = (sel) => idx().questions.map((q) => `<option value="${q.id}" ${q.id === sel ? 'selected' : ''}>Q${q.id} · ${esc(q.text.length > 54 ? q.text.slice(0, 52) + '…' : q.text)}</option>`).join('');
  const keepSel = (el, fallback) => { const cur = +el.value || fallback; el.innerHTML = qOpts(cur); };
  const head = (mod, title, text) => `<div class="pane-head"><h3><span class="mod">${mod}</span> ${title}</h3><p>${text}</p></div>`;
  const stat = (b, s) => `<div class="stat"><b>${b}</b><span>${s}</span></div>`;

  /* ---------- tabs ---------- */
  const refreshers = {};
  function openTab(name) {
    $$('#labTabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === name));
    $$('.tabpane').forEach((p) => { p.hidden = p.id !== 'pane-' + name; });
    if (refreshers[name]) refreshers[name]();
  }
  APP.openTab = openTab;
  APP.refreshLab = () => { const on = $('#labTabs .on'); if (on && refreshers[on.dataset.tab]) refreshers[on.dataset.tab](); };
  $('#labTabs').addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) openTab(b.dataset.tab); });

  /* ====================================================================
     M2 — STRING ALGORITHMS
     ==================================================================== */
  (function strings() {
    const pane = $('#pane-strings');
    pane.innerHTML = head('M2', 'String algorithms', 'Search the whole question database for a pattern with five different algorithms and compare how many character comparisons each one needs. Then find the longest common substring of two questions with a suffix array and the Kasai LCP array.') + `
      <div class="lab-grid">
        <div class="lab-ctrl">
          <div class="field"><label for="sPat">Pattern <span class="muted" style="text-transform:none;letter-spacing:0">(comma-separated for Aho–Corasick)</span></label><input id="sPat" type="text" value="linked list"></div>
          <div class="field"><label for="sAlg">Algorithm</label><select id="sAlg">
            <option value="kmp">Knuth–Morris–Pratt</option><option value="z">Z-function</option><option value="rk">Rabin–Karp (rolling hash)</option><option value="ac">Aho–Corasick (multi-pattern)</option><option value="naive">Naive O(nm)</option></select></div>
          <button class="btn primary" id="sRun">Search database</button>
        </div>
        <div class="lab-out" id="sOut"></div>
      </div>
      <hr style="border:0;border-top:1px solid var(--line);margin:28px 0">
      <div class="pane-head"><h3 style="font-size:17px">Longest common substring · suffix array + LCP</h3><p>Concatenate both questions with a separator, sort all suffixes, and scan neighbouring suffixes that come from different questions.</p></div>
      <div class="lab-grid">
        <div class="lab-ctrl">
          <div class="field"><label for="lcsA">Question A</label><select id="lcsA"></select></div>
          <div class="field"><label for="lcsB">Question B</label><select id="lcsB"></select></div>
          <button class="btn primary" id="lcsRun">Find substring</button>
        </div>
        <div class="lab-out" id="lcsOut"></div>
      </div>`;

    function search() {
      const alg = $('#sAlg').value, raw = $('#sPat').value.toLowerCase();
      const pats = alg === 'ac' ? raw.split(',').map((s) => s.trim()).filter(Boolean) : [raw.trim()].filter(Boolean);
      if (!pats.length) { $('#sOut').innerHTML = '<div class="empty">Enter a pattern.</div>'; return; }
      const ac = alg === 'ac' ? D.ahoCorasick(pats) : null;
      let cmpAlg = 0, cmpNaive = 0, extra = { hashChecks: 0, spurious: 0 }, matchedQ = 0, totalMatches = 0;
      const rows = [];
      idx().questions.forEach((q) => {
        const t = q.text.toLowerCase();
        let hits = [];
        pats.forEach((p) => { cmpNaive += D.naiveSearch(t, p).comparisons; });
        if (alg === 'ac') { const r = ac.search(t); cmpAlg += r.steps; hits = r.hits.map((h) => ({ s: h.start, l: h.pattern.length })); }
        else {
          const p = pats[0];
          const r = alg === 'kmp' ? D.kmpSearch(t, p) : alg === 'z' ? D.zSearch(t, p) : alg === 'rk' ? D.rabinKarp(t, p) : D.naiveSearch(t, p);
          cmpAlg += r.comparisons;
          if (r.hashChecks) { extra.hashChecks += r.hashChecks; extra.spurious += r.spurious; }
          hits = r.matches.map((s) => ({ s, l: p.length }));
        }
        if (hits.length) {
          matchedQ++; totalMatches += hits.length;
          const first = hits[0];
          rows.push(`<tr><td class="num">Q${q.id}</td><td>${esc(q.text.slice(0, first.s))}<mark>${esc(q.text.slice(first.s, first.s + first.l))}</mark>${esc(q.text.slice(first.s + first.l))}</td><td class="num">${hits.map((h) => h.s).join(', ')}</td></tr>`);
        }
      });
      let detail = '';
      if (alg === 'kmp') {
        const p = pats[0], f = D.kmpFailure(p).slice(0, 28);
        detail = `<div class="out-box"><h5>KMP failure function for “${esc(p)}”</h5><div class="chips">${f.map((v, i) => `<span class="chip">${esc(p[i] === ' ' ? '␣' : p[i])}:${v}</span>`).join('')}</div><p class="muted sm-t">f[i] = length of the longest proper prefix of the pattern that is also a suffix of p[0..i]. It lets the search never move backwards in the text.</p></div>`;
      } else if (alg === 'rk') {
        detail = `<div class="out-box"><h5>Rabin–Karp</h5><p class="sm-t" style="margin:0">${extra.hashChecks} window hashes compared (double polynomial hash), ${extra.spurious} spurious hit${extra.spurious === 1 ? '' : 's'} caught by verification. Average O(n + m).</p></div>`;
      } else if (alg === 'ac') {
        detail = `<div class="out-box"><h5>Aho–Corasick automaton</h5><p class="sm-t" style="margin:0">${pats.length} pattern${pats.length === 1 ? '' : 's'} → trie of ${ac.nodeCount} nodes with failure links. Each text character is processed once for all patterns together.</p></div>`;
      } else if (alg === 'z') {
        detail = `<div class="out-box"><h5>Z-function</h5><p class="sm-t" style="margin:0">Computed on pattern + separator + text. A position with Z ≥ pattern length is a match. Linear in the combined length.</p></div>`;
      }
      const advT = 'a'.repeat(2000), advP = 'a'.repeat(30) + 'b';
      const adv = `<div class="out-box"><h5>Worst-case demo · text “a”×2000, pattern “a”×30 + “b”</h5><p class="sm-t" style="margin:0">Naive: <b>${D.naiveSearch(advT, advP).comparisons.toLocaleString()}</b> comparisons · KMP: <b>${D.kmpSearch(advT, advP).comparisons.toLocaleString()}</b> · Z: <b>${D.zSearch(advT, advP).comparisons.toLocaleString()}</b>. On short everyday questions naive search exits early and can look competitive; KMP and Z guarantee O(n + m) even on adversarial text.</p></div>`;
      $('#sOut').innerHTML = `
        <div class="kv">${stat(totalMatches, 'matches')}${stat(matchedQ + ' / ' + idx().questions.length, 'questions hit')}${stat(cmpAlg.toLocaleString(), 'comparisons · ' + alg.toUpperCase())}${stat(cmpNaive.toLocaleString(), 'comparisons · naive')}</div>
        ${detail}${adv}
        <div class="tbl-wrap tall"><table class="tbl compact"><tr><th>ID</th><th>Question (first match highlighted)</th><th>Positions</th></tr>${rows.join('') || '<tr><td colspan="3" class="muted">No question contains the pattern.</td></tr>'}</table></div>`;
    }
    $('#sRun').addEventListener('click', search);
    $('#sAlg').addEventListener('change', search);
    $('#sPat').addEventListener('input', search);

    function lcs() {
      const a = idx().get($('#lcsA').value), b = idx().get($('#lcsB').value);
      if (!a || !b) return;
      const r = D.longestCommonSubstring(a.text.toLowerCase(), b.text.toLowerCase());
      $('#lcsOut').innerHTML = `
        <div class="kv">${stat('“' + esc(r.text.trim() || '—') + '”', 'longest common substring')}${stat(r.length, 'length (chars)')}${stat(r.n, 'suffixes sorted')}</div>
        <div class="out-box"><h5>First 12 rows of the suffix array (| marks the separator)</h5>
          <div class="tbl-wrap"><table class="tbl compact"><tr><th>Rank</th><th>Start</th><th>LCP with previous</th><th>Suffix</th></tr>${r.preview.map((x) => `<tr><td class="num">${x.rank}</td><td class="num">${x.start}</td><td class="num">${x.lcp}</td><td class="mono">${esc(x.suffix)}</td></tr>`).join('')}</table></div></div>`;
    }
    $('#lcsRun').addEventListener('click', lcs);
    $('#lcsA').addEventListener('change', lcs); $('#lcsB').addEventListener('change', lcs);

    refreshers.strings = () => { keepSel($('#lcsA'), 1); keepSel($('#lcsB'), 5); search(); lcs(); };
  })();

  /* ====================================================================
     M3 — EDIT DISTANCE (DP)
     ==================================================================== */
  (function dp() {
    const pane = $('#pane-dp');
    pane.innerHTML = head('M3', 'Edit distance · Wagner–Fischer', 'Fuzzy matching by dynamic programming. The table cell (i, j) holds the cheapest way to turn the first i items of A into the first j items of B. The highlighted path is the optimal alignment read back from the table.') + `
      <div class="lab-grid">
        <div class="lab-ctrl">
          <div class="field"><label for="dA">Sequence A</label><textarea id="dA" rows="2">reverse a linked list in Java</textarea></div>
          <div class="field"><label for="dB">Sequence B</label><textarea id="dB" rows="2">reverse a linked list using Java</textarea></div>
          <div class="field"><label for="dG">Compare by</label><select id="dG"><option value="w">Words</option><option value="c">Characters</option></select></div>
          <div class="field"><label for="dV">Variant</label><select id="dV"><option value="levenshtein">Levenshtein</option><option value="damerau">Damerau–Levenshtein (adjacent swap)</option></select></div>
          <div class="field"><label>Costs · insert / delete / substitute / swap</label>
            <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px"><input id="cI" type="number" min="0" value="1"><input id="cD" type="number" min="0" value="1"><input id="cS" type="number" min="0" value="1"><input id="cT" type="number" min="0" value="1"></div></div>
        </div>
        <div class="lab-out" id="dOut"></div>
      </div>`;
    function calc() {
      const g = $('#dG').value;
      const seq = (s) => (g === 'w' ? D.tokenize(D.normalize(s)) : s.toLowerCase().split(''));
      const A = seq($('#dA').value), B = seq($('#dB').value);
      const num = (id) => Math.max(0, +$(id).value || 0);
      const r = D.editDistance(A, B, { variant: $('#dV').value, ins: num('#cI'), del: num('#cD'), sub: num('#cS'), trans: num('#cT') });
      const worst = Math.max(A.length * num('#cD'), B.length * num('#cI'), 1);
      const sim = Math.max(0, 1 - r.distance / Math.max(worst, Math.max(A.length, B.length)));
      const on = new D.HashSet(); r.path.forEach((p) => on.add(p[0] + ',' + p[1]));
      let table = '<p class="muted">Table hidden for sequences longer than 26 items.</p>';
      if (A.length <= 26 && B.length <= 26) {
        table = '<div class="tbl-wrap"><table class="dp"><tr><th></th><th>ε</th>' + B.map((x) => `<th>${esc(x)}</th>`).join('') + '</tr>' +
          r.matrix.map((row, i) => `<tr><th>${i === 0 ? 'ε' : esc(A[i - 1])}</th>${row.map((v, j) => `<td class="${on.has(i + ',' + j) ? 'path' : ''}">${v}</td>`).join('')}</tr>`).join('') + '</table></div>';
      }
      $('#dOut').innerHTML = `
        <div class="kv">${stat(r.distance, 'edit distance')}${stat(pct(sim), 'normalised similarity')}${stat(A.length + ' × ' + B.length, 'table size (n × m)')}${stat((A.length + 1) * (B.length + 1), 'cells computed')}</div>
        <div class="out-box"><h5>Optimal alignment (A → B)</h5><div class="ops">${r.ops.map((o) => `<span class="op ${o.op}" title="${o.op}">${o.op === 'match' ? esc(o.a) : o.op === 'sub' ? esc(o.a) + '→' + esc(o.b) : o.op === 'swap' ? esc(o.a) + '⇄' + esc(o.b) : o.op === 'del' ? esc(o.a) : '+' + esc(o.b)}</span>`).join('') || '<span class="muted">identical</span>'}</div></div>
        <div class="out-box"><h5>DP table · time O(nm), space O(nm) (O(min(n,m)) if only the distance is needed)</h5>${table}</div>`;
    }
    ['#dA', '#dB'].forEach((s) => $(s).addEventListener('input', calc));
    ['#dG', '#dV', '#cI', '#cD', '#cS', '#cT'].forEach((s) => $(s).addEventListener('input', calc));
    refreshers.dp = calc;
  })();

  /* ====================================================================
     M4 — NETWORK FLOW
     ==================================================================== */
  (function flow() {
    const pane = $('#pane-flow');
    pane.innerHTML = head('M4', 'Network flow · capacitated assignment', 'A batch of incoming questions must be attached to existing threads. Each incoming question can join one thread, and each thread can absorb at most c new questions. That is a maximum-flow problem, solved with Edmonds–Karp: source → incoming (cap 1) → thread (if similar enough) → sink (cap c).') + `
      <div class="lab-grid">
        <div class="lab-ctrl">
          <div class="field"><label for="fIn">Incoming questions (one per line)</label><textarea id="fIn" rows="7">How can I reverse a Java linked list?
binary search code in Python
What is stack vs queue?
How to detect cycle in linked list
Explain heap sort
How do I find a loop in a linked list?</textarea></div>
          <div class="field"><label for="fThr">Similarity needed to link <b id="fThrV">30%</b></label><input id="fThr" type="range" min="10" max="90" step="5" value="30"></div>
          <div class="field"><label for="fCap">Thread capacity c</label><select id="fCap"><option>1</option><option>2</option><option>3</option></select></div>
        </div>
        <div class="lab-out" id="fOut"></div>
      </div>`;
    function calc() {
      const lines = $('#fIn').value.split('\n').map((s) => s.trim()).filter(Boolean);
      const thr = +$('#fThr').value / 100, cap = +$('#fCap').value;
      $('#fThrV').textContent = Math.round(thr * 100) + '%';
      const rightIndex = new D.HashMap(), rightIds = [], pairs = [], score = new D.HashMap();
      lines.forEach((ln, i) => {
        const res = idx().query(ln, { k: Math.max(1, idx().questions.length) });
        res.ranked.forEach((r) => {
          if (r.score < thr) return;
          let j = rightIndex.get(r.q.id);
          if (j === undefined) { j = rightIds.length; rightIndex.put(r.q.id, j); rightIds.push(r.q.id); }
          pairs.push([i, j]); score.put(i + '-' + j, r.score);
        });
      });
      const m = D.assignmentByFlow(lines.length, rightIds.length, pairs, cap);
      const assigned = new D.HashMap();
      m.matches.forEach(([i, j]) => assigned.put(i, j));
      const rows = lines.map((ln, i) => {
        const j = assigned.get(i);
        if (j === undefined) {
          const had = pairs.some((p) => p[0] === i);
          return `<tr><td>${esc(ln)}</td><td><span class="pill">new thread</span></td><td class="num">—</td><td class="muted">${had ? 'similar threads are full' : 'nothing similar enough'}</td></tr>`;
        }
        const q = idx().get(rightIds[j]);
        return `<tr><td>${esc(ln)}</td><td><b>Q${q.id}</b> ${esc(q.text)}</td><td class="num">${pct(score.get(i + '-' + j))}</td><td><span class="pill acc">linked</span></td></tr>`;
      }).join('');
      $('#fOut').innerHTML = `
        <div class="kv">${stat(m.size + ' / ' + lines.length, 'max flow = questions linked')}${stat(m.V, 'vertices')}${stat(m.E, 'edges')}${stat(m.augmentations, 'augmenting paths')}</div>
        <div class="tbl-wrap"><table class="tbl compact"><tr><th>Incoming question</th><th>Assigned thread</th><th>Similarity</th><th>Result</th></tr>${rows || '<tr><td colspan="4" class="muted">Add some questions.</td></tr>'}</table></div>
        <p class="muted sm-t" style="margin:0">Edmonds–Karp runs in O(V·E²). Candidate edges come from the inverted index, so the graph only contains pairs that share at least one shingle. Max-flow maximises how many questions get linked, not how good each link is (a min-cost flow would also prefer higher similarity). Try capacity 1 versus 3 to see the flow change.</p>`;
    }
    ['#fIn', '#fThr', '#fCap'].forEach((s) => $(s).addEventListener('input', calc));
    refreshers.flow = calc;
  })();

  /* ====================================================================
     M5 — APPROXIMATION (vertex cover on the duplicate graph)
     ==================================================================== */
  (function approx() {
    const pane = $('#pane-approx');
    pane.innerHTML = head('M5', 'Approximation · reviewing duplicate pairs', 'Join two questions with an edge when they look like duplicates. A moderator who reviews one question from each pair needs a minimum vertex cover — an NP-hard problem. The classic 2-approximation (take both ends of a maximal matching) is fast and never worse than twice the optimum.') + `
      <div class="lab-grid">
        <div class="lab-ctrl">
          <div class="field"><label for="aThr">Edge threshold <b id="aThrV">45%</b></label><input id="aThr" type="range" min="25" max="95" step="5" value="45"></div>
          <div class="out-box"><h5>How to read the graph</h5><p class="sm-t" style="margin:0"><span class="pill acc">amber</span> questions are in the approximate cover — reviewing them touches every duplicate pair. <span class="pill">navy</span> questions are not chosen. Hover a node for its text.</p></div>
        </div>
        <div class="lab-out" id="aOut"></div>
      </div>`;
    function calc() {
      const thr = +$('#aThr').value / 100;
      $('#aThrV').textContent = Math.round(thr * 100) + '%';
      const pairs = idx().duplicatePairs(thr);
      const edges = pairs.map((p) => [p.a, p.b]);
      if (!edges.length) { $('#aOut').innerHTML = '<div class="empty">No pairs reach this threshold. Lower it to build a duplicate graph.</div>'; return; }
      const vs = []; const seen = new D.HashSet();
      edges.forEach(([u, v]) => [u, v].forEach((x) => { if (!seen.has(x)) { seen.add(x); vs.push(x); } }));
      // union-find for duplicate groups
      const parent = new D.HashMap(); vs.forEach((v) => parent.put(v, v));
      const find = (x) => { while (parent.get(x) !== x) { parent.put(x, parent.get(parent.get(x))); x = parent.get(x); } return x; };
      edges.forEach(([u, v]) => { const a = find(u), b = find(v); if (a !== b) parent.put(a, b); });
      const comps = new D.HashMap();
      vs.forEach((v) => { const r = find(v); const c = comps.get(r) || []; c.push(v); comps.put(r, c); });
      let groups = []; comps.forEach((_, c) => groups.push(c));
      groups = D.mergeSort(groups, (a, b) => b.length - a.length || a[0] - b[0]);
      const ap = D.vertexCover2Approx(edges), inCover = new D.HashSet(); ap.cover.forEach((v) => inCover.add(v));
      const opt = D.minVertexCoverExact(vs, edges);

      const cols = Math.min(4, Math.max(1, Math.ceil(Math.sqrt(groups.length)))), cw = 760 / cols, rowsN = Math.ceil(groups.length / cols), ch = 190;
      const posOf = new D.HashMap();
      groups.forEach((g, gi) => {
        const cx = (gi % cols) * cw + cw / 2, cy = Math.floor(gi / cols) * ch + ch / 2, r = g.length === 1 ? 0 : Math.min(72, 22 + g.length * 9);
        g.forEach((v, i) => { const ang = (2 * Math.PI * i) / g.length - Math.PI / 2; posOf.put(v, { x: cx + r * Math.cos(ang), y: cy + r * Math.sin(ang) }); });
      });
      let svg = `<svg class="graph-svg" viewBox="0 0 760 ${rowsN * ch}" role="img" aria-label="Duplicate graph with approximate vertex cover">`;
      edges.forEach(([u, v]) => { const a = posOf.get(u), b = posOf.get(v); svg += `<line x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" stroke="#b9c6de" stroke-width="2"/>`; });
      vs.forEach((v) => {
        const p = posOf.get(v), c = inCover.has(v);
        svg += `<g><title>Q${v}: ${esc(idx().get(v).text)}</title><circle cx="${p.x}" cy="${p.y}" r="19" fill="${c ? '#d98e04' : '#16254a'}"/><text x="${p.x}" y="${p.y + 4.5}" text-anchor="middle" font-size="12.5" font-weight="700" fill="${c ? '#0a1226' : '#fff'}">Q${v}</text></g>`;
      });
      svg += '</svg>';
      const ratio = opt ? (ap.cover.length / opt).toFixed(2) : null;
      $('#aOut').innerHTML = `
        <div class="kv">${stat(vs.length, 'questions in duplicate pairs')}${stat(edges.length, 'duplicate pairs (edges)')}${stat(groups.length, 'duplicate groups')}${stat(ap.matching.length, 'maximal matching size')}${stat(ap.cover.length, 'approx. cover size')}${stat(opt === null ? 'n > 20' : opt, 'optimal cover')}${stat(ratio ? ratio + '×' : '—', 'actual ratio (bound 2×)')}</div>
        ${svg}
        <div class="out-box"><h5>Duplicate groups (connected components)</h5><div class="chips">${groups.map((g) => `<span class="chip">${g.map((v) => 'Q' + v).join(' · ')}</span>`).join('')}</div></div>`;
    }
    $('#aThr').addEventListener('input', calc);
    refreshers.approx = calc;
  })();

  /* ====================================================================
     M6 — RANDOMISED & PARALLEL
     ==================================================================== */
  (function random() {
    const pane = $('#pane-random');
    pane.innerHTML = head('M6', 'Randomised algorithms & parallel cost model', 'MinHash estimates Jaccard similarity from a short random signature, Miller–Rabin decides primality with witnesses (the engine uses it to size its hash tables), reservoir sampling draws a uniform sample in one pass, and a work/span model shows how far scoring could be parallelised. The detector itself still uses exact Jaccard similarity.') + `
      <div class="two" style="gap:24px">
        <div class="out-box">
          <h5>MinHash · universal hash family h(x) = (a·x + b) mod (2³¹ − 1)</h5>
          <div style="display:grid;gap:10px">
            <select id="mA" aria-label="Question A"></select><select id="mB" aria-label="Question B"></select>
            <div style="display:grid;grid-template-columns:1fr 90px;gap:10px;align-items:end">
              <div class="field"><label for="mK">Signature length k <b id="mKV">64</b></label><input id="mK" type="range" min="4" max="256" step="4" value="64"></div>
              <div class="field"><label for="mSeed">Seed</label><input id="mSeed" type="number" value="42"></div></div>
          </div>
          <div id="mOut" style="margin-top:12px"></div>
        </div>
        <div style="display:grid;gap:24px;align-content:start">
          <div class="out-box">
            <h5>Miller–Rabin primality</h5>
            <div style="display:flex;gap:8px"><input id="prN" type="text" value="1000000007" aria-label="Number to test"><button class="btn primary sm" id="prGo">Test</button></div>
            <div class="chips" style="margin-top:8px" id="prEx"></div>
            <div id="prOut" style="margin-top:10px"></div>
          </div>
          <div class="out-box">
            <h5>Reservoir sampling · uniform sample in one pass</h5>
            <div style="display:grid;grid-template-columns:1fr auto;gap:10px;align-items:end">
              <div class="field"><label for="rK">Sample size k <b id="rKV">5</b></label><input id="rK" type="range" min="1" max="10" value="5"></div>
              <button class="btn ghost sm" id="rGo">Resample</button></div>
            <div id="rOut" style="margin-top:10px"></div>
          </div>
        </div>
      </div>
      <div class="out-box" style="margin-top:24px"><h5>Parallel scoring · work and span (model)</h5><div id="wsOut"></div></div>`;

    const xsOf = (q) => q.pre.shingles.map((s) => parseInt(s.hash.slice(0, 8), 16));
    function minhash() {
      const a = idx().get($('#mA').value), b = idx().get($('#mB').value);
      if (!a || !b) return;
      const k = +$('#mK').value, seed = +$('#mSeed').value || 1;
      $('#mKV').textContent = k;
      const exact = D.HashSet.jaccard(a.pre.set, b.pre.set).score;
      const sa = D.minHashSignature(xsOf(a), k, seed), sb = D.minHashSignature(xsOf(b), k, seed);
      const e = D.minHashEstimate(sa, sb);
      const se = Math.sqrt((exact * (1 - exact)) / k);
      const conv = [8, 16, 32, 64, 128, 256].map((kk) => {
        const est = D.minHashEstimate(D.minHashSignature(xsOf(a), kk, seed), D.minHashSignature(xsOf(b), kk, seed)).estimate;
        return `<tr><td class="num">${kk}</td><td class="num">${est.toFixed(3)}</td><td class="num">${Math.abs(est - exact).toFixed(3)}</td></tr>`;
      }).join('');
      $('#mOut').innerHTML = `
        <div class="kv">${stat(exact.toFixed(3), 'exact Jaccard')}${stat(e.estimate.toFixed(3), 'MinHash estimate')}${stat(Math.abs(e.estimate - exact).toFixed(3), 'absolute error')}${stat('±' + se.toFixed(3), 'expected std. error')}</div>
        <div class="sig" style="margin:12px 0">${e.slots.map((m) => `<i class="${m ? 'm' : ''}"></i>`).join('')}</div>
        <p class="muted sm-t" style="margin:0 0 8px">Each square is one hash function; amber means both questions had the same minimum, which happens with probability equal to the Jaccard similarity.</p>
        <table class="tbl compact"><tr><th>k</th><th>estimate</th><th>|error|</th></tr>${conv}</table>`;
    }
    ['#mA', '#mB', '#mK', '#mSeed'].forEach((s) => $(s).addEventListener('input', minhash));

    const examples = [['561', 'Carmichael number'], ['1000000007', 'prime'], ['3215031751', 'strong pseudoprime to bases 2, 3, 5, 7']];
    $('#prEx').innerHTML = examples.map((x) => `<button class="pill" style="border:0;cursor:pointer" data-n="${x[0]}" title="${x[1]}">${x[0]}</button>`).join('');
    $('#prEx').addEventListener('click', (e) => { const b = e.target.closest('[data-n]'); if (b) { $('#prN').value = b.dataset.n; prime(); } });
    function prime() {
      const raw = $('#prN').value.trim();
      let out;
      try {
        if (!/^\d{1,40}$/.test(raw)) throw new Error('digits only');
        const det = D.millerRabin(raw), rnd = D.millerRabinRandom(raw, 8, D.mulberry32(Date.now() & 0xffff));
        const cap = idx().inverted.cap, capOk = D.millerRabin(cap).prime;
        out = `<div class="kv">${stat(det.prime ? 'prime' : 'composite', 'deterministic (12 bases)')}${stat(rnd.prime ? 'probably prime' : 'composite', 'Monte Carlo, 8 random bases')}${stat(det.witness || '—', 'witness')}</div>
          <p class="muted sm-t" style="margin:10px 0 0">Deterministic test: ${esc(det.note)}. A Monte-Carlo “composite” answer is always right; a “probably prime” answer errs with probability ≤ 4⁻⁸ for a composite. The index currently has <b>${cap}</b> buckets — Miller–Rabin confirms that ${capOk ? 'is prime ✓' : 'is not prime'}.</p>`;
      } catch (err) { out = `<p class="muted">Enter a non-negative integer (up to 40 digits).</p>`; }
      $('#prOut').innerHTML = out;
    }
    $('#prGo').addEventListener('click', prime);
    $('#prN').addEventListener('keydown', (e) => { if (e.key === 'Enter') prime(); });

    let rSeed = 7;
    function reservoir() {
      const k = +$('#rK').value; $('#rKV').textContent = k;
      const s = D.reservoirSample(idx().questions, k, D.mulberry32(rSeed));
      $('#rOut').innerHTML = `<div class="chips" style="flex-direction:column;gap:6px">${s.map((q) => `<span class="chip" style="font-family:var(--sans);font-size:13px">Q${q.id} · ${esc(q.text)}</span>`).join('')}</div>
        <p class="muted sm-t" style="margin:8px 0 0">Every question had probability k/N = ${k}/${idx().questions.length} of being kept. One pass, O(k) memory.</p>`;
    }
    $('#rK').addEventListener('input', reservoir);
    $('#rGo').addEventListener('click', () => { rSeed = Math.floor(Math.random() * 1e9); reservoir(); });

    function workspan() {
      const c = APP.last ? APP.last.stats.candidates : 12, k = APP.settings.k;
      const w = D.workSpan(c, k);
      $('#wsOut').innerHTML = `<div class="kv">${stat(c, 'candidates to score')}${stat(w.work, 'work T₁ (units)')}${stat(w.span, 'span T∞ (units)')}${stat(w.ceiling.toFixed(1) + '×', 'speed-up ceiling T₁ / T∞')}${stat(w.brent(4).toFixed(1), 'Brent bound, p = 4')}${stat(w.brent(8).toFixed(1), 'Brent bound, p = 8')}</div>
        <p class="muted sm-t" style="margin:10px 0 0">Scoring candidates is embarrassingly parallel (each Jaccard is independent); merging into the top-K is a log-depth reduction. These are model figures from the number of candidates in your last query — not measured timings.</p>`;
    }

    refreshers.random = () => { keepSel($('#mA'), 1); keepSel($('#mB'), 5); minhash(); prime(); reservoir(); workspan(); };
  })();

  openTab('strings');
};
