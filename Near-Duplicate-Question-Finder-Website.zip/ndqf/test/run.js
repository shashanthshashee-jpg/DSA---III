// Node sanity tests: node test/run.js
const fs = require('fs'), path = require('path'), vm = require('vm');
globalThis.window = undefined;
['ds', 'text', 'algos', 'engine', 'data'].forEach((f) => vm.runInThisContext(fs.readFileSync(path.join(__dirname, '..', 'js', f + '.js'), 'utf8'), { filename: f }));
const D = globalThis.DSA;
let pass = 0, fail = 0;
const ok = (c, m) => { if (c) pass++; else { fail++; console.log('FAIL:', m); } };
const eq = (a, b, m) => ok(JSON.stringify(a) === JSON.stringify(b), m + ' -> got ' + JSON.stringify(a) + ' want ' + JSON.stringify(b));

// HashMap / HashSet
const hm = new D.HashMap(); for (let i = 0; i < 500; i++) hm.put('k' + i, i);
ok(hm.n === 500 && hm.get('k321') === 321 && hm.get('nope') === undefined, 'hashmap basic');
hm.remove('k5'); ok(!hm.has('k5') && hm.n === 499, 'hashmap remove');
ok(hm.stats().loadFactor <= 0.75 && D.millerRabin(hm.cap).prime, 'hashmap load + prime cap');
const A = new D.HashSet(), B = new D.HashSet(); ['a','b','c','d'].forEach(x=>A.add(x)); ['a','b','c','e'].forEach(x=>B.add(x));
eq(D.HashSet.jaccard(A, B).score, 0.6, 'jaccard 3/5');

// heap / topk
const tk = new D.TopK(3); [[1,.2],[2,.9],[3,.5],[4,.7],[5,.1],[6,.9]].forEach(([id,score])=>tk.offer({id,score}));
eq(tk.result().map(r=>r.id), [2,6,4], 'topk order + tie by id');

// text
const p = D.preprocess('How do I reverse a linked list in Java?', '2');
eq(p.kept, ['reverse','linked','list','java'], 'stopwords');
eq(p.shingles.map(s=>s.text), ['reverse linked','linked list','list java'], '2-shingles');
eq(D.preprocess('What is the best way to reverse a Java linked list?','1').kept, ['reverse','java','linked','list'], 'Q-B tokens');

// number theory
ok(D.millerRabin(1000000007).prime && !D.millerRabin(561).prime && D.millerRabin(561).witness, 'miller-rabin + carmichael 561');
ok(!D.millerRabin('3825123056546413051').prime, 'mr composite strong pseudoprime');
ok(D.nextPrime(24) === 29, 'nextPrime');

// strings
const T = 'abracadabra abracadabra', P = 'abra';
const exp = D.naiveSearch(T, P).matches;
['kmpSearch','zSearch','rabinKarp'].forEach(f => eq(D[f](T, P).matches, exp, f));
ok(D.kmpSearch('a'.repeat(1000), 'a'.repeat(10)+'b').comparisons < D.naiveSearch('a'.repeat(1000), 'a'.repeat(10)+'b').comparisons, 'kmp fewer comparisons');
const ac = D.ahoCorasick(['he','she','his','hers']).search('ushers');
eq(ac.hits.map(h=>h.pattern).sort(), ['he','hers','she'], 'aho-corasick');
eq(D.longestCommonSubstring('xabcdy','zabcdw').text, 'abcd', 'LCS suffix array');
eq(D.suffixArray('banana'), [5,3,1,0,4,2], 'suffix array banana');

// DP
eq(D.editDistance('kitten','sitting').distance, 3, 'levenshtein');
eq(D.levenshtein('kitten','sitting'), 3, 'levenshtein fast');
eq(D.editDistance('ca','ac',{variant:'damerau'}).distance, 1, 'damerau swap');
eq(D.editDistance(['a','b','c'],['a','c']).distance, 1, 'token edit distance');

// flow
const m = D.assignmentByFlow(3, 3, [[0,0],[0,1],[1,0],[2,1],[2,2]], 1);
eq(m.size, 3, 'max bipartite matching');
const m2 = D.assignmentByFlow(3, 1, [[0,0],[1,0],[2,0]], 2);
eq(m2.size, 2, 'capacity-2 assignment');

// approximation
const edges = [[1,2],[2,3],[3,4],[4,5],[5,6]];
const vc = D.vertexCover2Approx(edges), opt = D.minVertexCoverExact([1,2,3,4,5,6], edges);
ok(vc.cover.length <= 2 * opt && edges.every(([u,v]) => vc.cover.includes(u) || vc.cover.includes(v)), '2-approx vertex cover');

// minhash
const xs1 = [1,2,3,4,5,6,7,8], xs2 = [5,6,7,8,9,10,11,12];
const e = D.minHashEstimate(D.minHashSignature(xs1, 512, 7), D.minHashSignature(xs2, 512, 7)).estimate;
ok(Math.abs(e - 4/12) < 0.08, 'minhash close to 1/3, got ' + e);
eq(D.reservoirSample([...Array(100).keys()], 5, D.mulberry32(1)).length, 5, 'reservoir');

// engine: indexed == exhaustive
const idx = new D.QuestionIndex('1+2'); idx.load(D.SEED_BANK);
['How can I reverse a Java linked list?','binary seerch in python','what is jaccard similarity of sets','heap k largest','xyzzy plugh'].forEach(q => {
  const a = idx.query(q, { k: 5 }), b = idx.exhaustive(q, { k: 5 });
  eq(a.ranked.map(r=>r.q.id), b.ids, 'indexed == exhaustive for "' + q + '"');
});
const top = idx.query('How can I reverse a Java linked list?', { k: 5 });
console.log('Top for deck example:', top.ranked.map(r => `Q${r.q.id} ${(r.score*100).toFixed(0)}%`).join(', '), '| candidates', top.stats.candidates, 'of', top.stats.total);
console.log('suggest:', JSON.stringify(idx.suggest(D.preprocess('reverse linkd list in jva','1+2'))));
console.log('pairs@0.5:', idx.duplicatePairs(0.5).length);
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
