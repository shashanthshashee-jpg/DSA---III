# Near-Duplicate Question Finder for Q&A Platforms
Data Structures and Algorithms – 3 (25CS2103E) · Academic year 2026–2027 · Section 11
Team: M Shashanth, M Anthony Akshay · Guide: Mrs. Ch. Anitha, Assistant Professor, CS&IT

A single-page website with no dependencies and no build step.

## Run in VS Code
1. Open this folder in VS Code (`File → Open Folder…`).
2. Either double-click `index.html`, or install the **Live Server** extension, right-click `index.html` → *Open with Live Server*.
3. Optional logic tests: `node test/run.js` (needs Node.js; prints `32 passed, 0 failed`).

## Folder map
| File | What it holds |
|---|---|
| `index.html`, `css/styles.css` | Page structure and styling |
| `js/ds.js` | Hand-built HashMap (chaining, prime capacity), HashSet, MinHeap, bounded Top-K priority queue, Miller–Rabin |
| `js/text.js` | Normalisation, tokenisation, stop-word HashSet, shingling, double polynomial hash |
| `js/engine.js` | Inverted index, candidate retrieval, HashSet Jaccard, Top-K ranking, exhaustive baseline, "did you mean" |
| `js/algos.js` | KMP, Z, Rabin–Karp, Aho–Corasick, suffix array + LCP, edit distance, Edmonds–Karp, vertex-cover 2-approx, MinHash, reservoir sampling |
| `js/lab.js` | The Algorithm Lab tabs (syllabus modules 2–6) |
| `js/ui.js` | Detector, pipeline, index, ranking and database sections |
| `js/data.js` | 48 seed questions (Q1–Q4 are the deck's worked example) |

## Where the syllabus appears (no separate page)
M1 engine with several query classes (Detector, database filter, "did you mean") · M2 Algorithm Lab → String algorithms · M3 → Edit distance · M4 → Network flow · M5 → Approximation · M6 → Randomised. The "Syllabus map" section is a jump-menu on the same page.

## Honest notes
- The engine uses its own HashMap/HashSet/heap; `Array` is the only built-in container, and no built-in sort is used.
- Numbers on screen (candidates, comparisons, timings, MinHash errors) are computed live in your browser. The ranking table in the PPT (95 %, 92 %…) is illustrative; the live scores depend on the shingle mode you choose.
- Jaccard similarity measures overlap of shingle sets, not meaning. Fully paraphrased duplicates with no shared words will not be found.
- Questions you add are saved in the browser's localStorage only.
